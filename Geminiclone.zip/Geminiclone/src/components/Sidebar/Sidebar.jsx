import React,{useState}from 'react'
import './Sidebar.css'
import {assets} from '../../assets/assets/assets'




function Sidebar() {
    
        const [extend, setExtend]=useState(false)
    

  return (
    <div className='sidebar'>
        <div className="top">
            <div className="menu">
            <img  onClick={()=>setExtend(prev=>!prev)}  src={assets.menu_icon} alt="menuicon"/>{extend?<p></p>:null}</div>
            <div className="newchat">
                <img src={assets.plus_icon} alt="newchaticon"/>
               {extend? <p>New Chat</p>:null}
            </div>
           {extend? <div className="recent">
                <p className="recenttitle">Recent</p>
                <div className="recententry">
                    <img src={assets.message_icon} alt="messageicon"/>
                    <p>What is react......</p> 
                </div>
            </div>:null}

        </div>
        <div className="bottom">
            <div className="bottomitem">
                <img src={assets.question_icon} alt="questionicon"/>
                {extend?<p>Help</p>:null}
            </div>
            <div className="bottomitem">
                <img src={assets.history_icon} alt="historyicon"/>
               {extend? <p>Activity</p>:null}
            </div>
            <div className="bottomitem">
                <img src={assets.setting_icon} alt="settingicon"/>
              {extend?  <p>Settings</p>:null}
            </div>

        </div>

    </div>
  )
}

export default Sidebar