import React from 'react'
import './MainContent.css'
import { assets } from '../../assets/assets/assets'

function MainContent() {
  return (
    <div className="main">
        <div className="nav">
            <p>Gemini</p>
            <img src={assets.user_icon} alt="usericon"/>
        </div>
        <div className="maincontainer">
            <div className="greet">
                <p><span>Hello Gunaal</span></p>
                <p>How can I help you today?</p>
            </div>
            <div className="cards">
                <div className="card">
                    <p>Suggest beautiful places to see</p>
                    <img src={assets.compass_icon} alt="compassicon"/>
                </div>
                <div className="card">
                    <p>Suggest beautiful places to see</p>
                    <img src={assets.bulb_icon} alt="bulbicon"/>
                </div>
                <div className="card">
                    <p>Suggest beautiful places to see</p>
                    <img src={assets.message_icon} alt="messageicon"/>
                </div>
                <div className="card">
                    <p>Suggest beautiful places to see</p>
                    <img src={assets.code_icon} alt="codeicon"/>
                </div>
            </div>
            <div className="mainbottom">
                <div className="searchbox">
                    <input type="text" placeholder="Enter a prompt here"/>
                    <div>
                        <img src={assets.gallery_icon} alt="galleryicon" />
                        <img src={assets.mic_icon} alt="micicon" />
                        <img src={assets.send_icon} alt="sendicon" />
                    </div>
                </div>
                <p className="bottominfo">Gemini may display inaccurate info, including about people, so double-check its responses. Your privacy and Gemini Apps</p>
            </div>
        </div>
    </div>
  )
}

export default MainContent