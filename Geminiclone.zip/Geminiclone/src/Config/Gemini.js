// const apiKey="AIzaSyA40PuyBvyhtNCOrN1o_GDV35iTG4RnrEg";


// Rest of your code


import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from '@google/generative-ai'
/*
 * Install the Generative AI SDK
 *
 * $ npm install @google/generative-ai
 *
 * See the getting started guide for more information
 * https://ai.google.dev/gemini-api/docs/get-started/node
 */



  const MODEL_NAME="gemini-1.0-pro"
  const API_KEY="AIzaSyA40PuyBvyhtNCOrN1o_GDV35iTG4RnrEg"
  
  
//   const apiKey = process.env.GEMINI_API_KEY;
//   const genAI = new GoogleGenerativeAI(apiKey);
  
//   const model = genAI.getGenerativeModel({
//     model: "gemini-1.5-flash",
//   });
  
  const generationConfig = {
    temperature: 1,
    topP: 0.95,
    topK: 64,
    maxOutputTokens: 8192,
    responseMimeType: "text/plain",
  };
  
   function run(prompt) {
    const genAI=new GoogleGenerativeAI(API_KEY);
    const model = genAI.getGenerativeModel({model:MODEL_NAME})
//     const chatSession = model.startChat({
//       generationConfig,
//    // safetySettings: Adjust safety settings
//    // See https://ai.google.dev/gemini-api/docs/safety-settings
//       history: [
//       ],
//     });
const safetySettings=[
    {
        category:HarmCategory.HARM_CATEGORY_HARASSMENT,
        threshold:HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        
    },
    {
        category:HarmCategory.HARM_CATEGORY_HATE_SPEECH,
        threshold:HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    {
        category:HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
        threshold:HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,

    },

    {
        category:HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
        threshold:HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
];
const chat=model.startChat({
    generationConfig,
    safetySettings,
    history: [],


});
  
    const result =  chatSession.sendMessage(prompt);
    console.log(result.response.text());
  }
  
   export default run;