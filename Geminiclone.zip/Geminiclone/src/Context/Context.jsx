import { createContext } from "react";
import run from "../Config/Gemini"

export const Context=createContext();

const ContextProvider=(props)=>{
    // const onSet=(prompt)=>{
    //     run(prompt)
    // }
    // onSet("what is React js")

    const contextValue={

    }
    return(
        <ContextProvider value={contextValue}>
            {props.children}
        </ContextProvider>
    )
}
export default ContextProvider